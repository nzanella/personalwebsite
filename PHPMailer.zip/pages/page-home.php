<?php
/**
 * @package NeilGlenZanellaWebSite
 */
?>
<div style="font-size: 24pt; font-weigth: bold;">
<p><?php echo $pageContents->getContents("paragraph1"); ?></p><br />
<p><?php echo $pageContents->getContents("paragraph2"); ?></p><br />
<p><?php echo $pageContents->getContents("paragraph3"); ?></p><br />
<p><?php echo $pageContents->getContents("paragraph4"); ?></p><br />
</div>
