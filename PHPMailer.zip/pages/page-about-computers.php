<?php
/**
 * @package NeilGlenZanellaWebSite
 */
?>
        <div id="aboutShortBioComp">
          <img class="aboutBioPic" alt="Neil Zanella" src="<?php echo $pageSettings->getFile("images/NeilZanellaBioPic.jpg"); ?>" />
          <?php echo $pageContents->getContents("aboutComputerScience"); ?>
        </div>
