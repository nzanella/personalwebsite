<?php
/**
 * @package NeilGlenZanellaWebSite
 */
?>
<p class="topParagraph"><?php echo $pageContents->getContents("mathtrainTopParagraph"); ?></p>
<ul class="train">
  <li><?php echo $pageContents->getContents("mathtrainLI1"); ?></li>
  <li><?php echo $pageContents->getContents("mathtrainLI2"); ?></li>
  <li><?php echo $pageContents->getContents("mathtrainLI3"); ?></li>
  <li><?php echo $pageContents->getContents("mathtrainLI4"); ?></li>
  <li><?php echo $pageContents->getContents("mathtrainLI5"); ?></li>
  <li><?php echo $pageContents->getContents("mathtrainLI6"); ?></li>
  <li><?php echo $pageContents->getContents("mathtrainLI7"); ?></li>
  <li><?php echo $pageContents->getContents("mathtrainLI8"); ?></li>
</ul>
