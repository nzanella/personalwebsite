<?php
/**
 * @package NeilGlenZanellaWebSite
 */
?>
        <div id="aboutShortBioLang">
          <img class="aboutBioPic" alt="Neil Zanella" src="<?php echo $pageSettings->getFile("images/NeilZanellaBioPic.jpg"); ?>" />
          <?php echo $pageContents->getContents("aboutLanguages"); ?>
        </div>
