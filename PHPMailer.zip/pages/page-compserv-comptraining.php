<?php
/**
 * @package NeilGlenZanellaWebSite
 */
?>
<p class="topParagraph"><?php echo $pageContents->getContents("comptrainTopParagraph"); ?></p>
<ul class="train">
  <li>
    <p><?php echo $pageContents->getContents("comptrainLI1"); ?></p>
    <ul class="traininner">
      <li>HTML</li>
      <li>CSS</li>
      <li>JavaScript</li>
      <li>jQuery</li>
      <li>PHP</li>
      <li>SQL</li>
      <li>WordPress CMS</li>
      <li>Magento CMS</li>
    </ul>
  </li>
  <li>
    <p><?php echo $pageContents->getContents("comptrainLI2"); ?></p>
    <ul class="traininner">
      <li>C</li>
      <li>C++</li>
      <li>C#</li>
      <li>Java</li>
    </ul>
  </li>
  <li>
    <p><?php echo $pageContents->getContents("comptrainLI3"); ?></p>
  </li>
  <li>
    <p><?php echo $pageContents->getContents("comptrainLI4"); ?></p>
  </li>
</ul>
