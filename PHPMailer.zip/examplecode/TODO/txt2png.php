<?php
/**
 *
 */

  function txt2png($textFile) {

  }

  txt2png("test.php");
